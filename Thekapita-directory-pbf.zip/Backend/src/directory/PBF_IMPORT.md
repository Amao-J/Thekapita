# Directory PBF import and photo storage

## What the importer does

`import_osm_places` reads a local OpenStreetMap PBF file with PyOsmium. It selects named map features inside the Abuja and Lagos bounding boxes and maps OSM tags to the Directory's existing categories: restaurants, businesses, healthcare, schools, and government. Nodes, ways, and relations are normalized to the same `elements` format as an Overpass JSON response. Imported rows are approved, marked as OpenStreetMap-sourced, and keyed by their OSM type and ID, so rerunning an import updates rather than duplicates them. Listings claimed by an owner are not overwritten.

The PBF is an input only; it is not required by the API at runtime and is intentionally excluded from the source bundle. No OSRM or map-tile server is needed to import or serve directory records.

## Produce and import the small JSON snapshot

Install the backend requirements, including PyOsmium, and place a Geofabrik Nigeria extract at a local path. From `Backend/src`:

```powershell
python manage.py import_osm_places --pbf C:\data\nigeria-latest.osm.pbf --cities Abuja,Lagos --categories all --export-json directory\exports\abuja-lagos.json --dry-run
```

Review the dry-run counts, then import the snapshot without the PBF:

```powershell
python manage.py import_osm_places --file directory\exports\abuja-lagos.json --categories all --dry-run
python manage.py import_osm_places --file directory\exports\abuja-lagos.json --categories all
```

Alternatively, run the first command again without `--dry-run` to read and import directly from the PBF. The JSON snapshot contains only the selected city features and import metadata; it is reusable without the original PBF. The `elements` records preserve the OSM tags used by the importer.

The bounding boxes and supported tag mappings live in `importers.py`; category and city parsing is in `management/commands/import_osm_places.py`. Use the models and migration alongside those files to understand the persisted record structure.

The source bundle also retains `Backend/src/products.json` unchanged. That product catalogue is separate from the PBF-derived Directory snapshot.

## OSM attribution

Show `© OpenStreetMap contributors` wherever imported records are displayed. OpenStreetMap data is made available under the Open Database License (ODbL); retain the attribution and review ODbL obligations before redistributing a derived database.

## Private S3 listing photos

Directory photos are stored by S3 object key in `Listing.image_key`, not as files on the Django server. The authenticated API creates a short-lived presigned S3 POST policy, the browser uploads directly to the private bucket, and the API stores the issued key after checking the stored object's type and size. Photo URLs are short-lived presigned GET URLs.

Configure the same private S3-compatible credentials used by the app's default storage. The bucket must allow browser POSTs from the deployed site and local Vite origin; a suitable CORS rule is:

```json
[
  {
    "AllowedOrigins": [
      "https://thekapita.com",
      "https://www.thekapita.com",
      "http://localhost:5173"
    ],
    "AllowedMethods": ["POST"],
    "AllowedHeaders": ["*"],
    "ExposeHeaders": ["ETag"],
    "MaxAgeSeconds": 3000
  }
]
```

Keep the bucket private. Owners can upload photos to their own listings; staff can add photos to unclaimed map listings. A map `image` tag is not copied automatically because its reuse rights may differ from the OSM data license.
